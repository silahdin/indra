@extends('layouts.appcompro')

@section('content')
<?php
$imgBanner = asset('assets/compro/assets/frontend_assets/images/slider/about.jpg');
?>

<div class="space-top"></div>

	<section class="about flex-box" style="background:url('{{$imgBanner}}'); background-size: cover; height: 500px;">
		<div class="boxes">
			<h1>@lang('main.tlone_leader')</h1>
			<p>@lang('main.tlone_leader_detail')</p>

			<p>@lang('main.tlone_leader_profile')
				<span style="position:hidden">
					<span id="profileLeader"></span>
				</span>
			</p>
		</div>
	</section>
	<br>
	<br>
	<br>
	<section class="person-leader detail-leader">
		<div class="container container-custom">
			<div class="row">
				<div class="col-sm-3">
					<img class="img-tl-res-dif"  src="{{asset($leader->img)}}" alt="">
					<!-- <img src="./assets/compro/images/about/Aditiya.png" alt=""> -->
				</div>
				<div class="col-sm-9">
					<h2>{{ $leader->nama }}</h2>
					<h5>{{ $leader->jabatan }}</h5>
					<p>{!! $leader->full_summary !!}</p>
				</div>
			</div>
			<br>


		</div>
	</section>

	<section class="person-leader-tab">
		<div class="container container-custom">
			<div class="row">
				<div class="col-sm-12">
					<input id="tab1" type="radio" name="tabs" checked>
					<label for="tab1">Educations & Certifications</label>

					<input id="tab2" type="radio" name="tabs">
					<label for="tab2">Areas of Expertise</label>

					<input id="tab3" type="radio" name="tabs">
					<label for="tab3">Industries</label>

					<input id="tab4" type="radio" name="tabs">
					<label for="tab4">Professional Societies</label>

					<section id="content1" class="single-content">

					<h6>Educations & Certifications</h6>
							{!! $leader->edu_cert !!}

					</section>

					<section id="content2" class="single-content">
					<h6>Areas of Expertise</h6>
              {!! $leader->expertise !!}

					</section>

					<section id="content3" class="single-content">
					<h6>Industries</h6>
                            {!! $leader->industries !!}
					</section>

					<section id="content4" class="single-content">
					<h6>Professional Societies</h6>
                            {!! $leader->pro_societies !!}
					</section>
					<hr>

				</div>
			</div>
		</div>
	</section>

	<br>
	<br>
    <section class="about flex-box" style="background-color:#8c9090;text-align:center;color:wheat">
		<div class="container" style="">
			<div style="margin-top:15px">
				<span>FOLLOW US</span>
			</div>
			<div style="font-size:xx-large">
				<a href="https://www.linkedin.com/company/reandabernardi/" style="color:wheat"><span class="fa fa-linkedin"></span></a>
			</div>
		</div>
	</section>

@endsection
