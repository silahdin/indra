@extends('layouts.appcompro')

@section('content')

<?php
$imgBanner = asset('assets/compro/assets/frontend_assets/images/banner/Banner Page Audit & Assurance.jpg');
?>
	<div class="space-top">
	</div>

	<section class="about flex-box"
		style="background:url('{{$imgBanner}}'); background-size: cover; height: 500px;">
		<div class="boxes">
			<h1>@lang('services_lists_title')</h1>
		</div>
	</section>
	<section  class="services-page">
		<div class="container container-content">
			<div class="row">
					<!-- <div class="row"> -->
						<div class="col-sm-12 col-text-program">
                            <h6 style="line-height:1.5">@lang('main.services_lists_detail')</h6>
                             <h6 style="line-height:1.5">@lang('main.services_lists_des')</h6>
						</div>
					<!-- </div> -->
			</div>
		</div>
	</section>
    <section style="background-color:#f8f9fa;">
    <br><br>
        <div class="container container-content">
			<h4 style="font-weight:900">@lang('main.services_lists_core_service')</h4>
            <div class="row">

					<?php if($med==$size){
						?>
						<div class="col-sm-6">
							<div class="nav-services flex-box" style="margin:1.5px">
								<a href="{{ route('compro.servListId', ['id'=> $services[0]->service_id]) }}" class="btnc-more" style="padding:5px 15px;margin:inherit">{{ $services[0]->name}}</a>
							</div>
						</div>
                </div>
					<?php }else {?>
						<div class="col-sm-6">
							<div class="nav-services flex-box" style="margin:1.5px">
								<?php for($i=0;$i<$med;$i++){?>
									<a href="{{ route('compro.servListId', ['id'=> $services[$i]->service_id]) }}" class="btnc-more" style="padding:5px 15px;margin:inherit">{{ $services[$i]->name}}</a>
								<?php echo'';}?>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="nav-services flex-box" style="margin:1.5px">
								<?php for($j=$med;$j<$size;$j++){?>
									<a href="{{ route('compro.servListId', ['id'=> $services[$j]->service_id]) }}" class="btnc-more" style="padding:5px 15px;margin:inherit">{{ $services[$j]->name}}</a>
								<?php echo'';}?>
							</div>
						</div>
					<?php echo "";}?>
            </div>
        </div>
        <br><br><br>
    </section>

	<section class="about flex-box" style="background-color:#8c9090;text-align:center;color:wheat">
		<div class="container" style="">
			<div style="margin-top:15px">
				<span>FOLLOW US</span>
			</div>
			<div style="font-size:xx-large">
				<a href="https://www.linkedin.com/company/reandabernardi/" style="color:wheat"><span class="fa fa-linkedin"></span></a>
			</div>
		</div>
	</section>

@endsection
