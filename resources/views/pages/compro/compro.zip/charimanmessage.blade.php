@extends('layouts.appcompro')

@section('content')
<?php
$imgBanner = asset('assets/compro/assets/frontend_assets/images/slider/about.jpg');
?>
<?php 
$setocv = DB::table('cms_setting')
->select('images_cm', 'name_cm', 'title_cm', 'subtitle_cm', 'charimanmsg')
->where('id', 1)
->first();
?>

<div class="space-top"></div>

	<br><br>
	<section class="person-leader detail-leader">
		<div class="container container-custom">
			<div class="row">
				<div class="col-sm-3">
					<img class="img-tl-res-dif"  src="{{$setocv->images_cm}}" alt="">
					<!-- <img src="./assets/compro/images/about/Aditiya.png" alt=""> -->
				</div>
				<div class="col-sm-9">
					<h2>{{$setocv->name_cm}}</h2>
					<h5 style="margin-bottom: 0px !important">{{$setocv->title_cm}}</h5>
					<span style="font-size: 12px">{{$setocv->subtitle_cm}}</span>
					<br><br>
					{!!$setocv->charimanmsg!!}
					<br>
				</div>
			</div>
			<br>


		</div>
	</section>



	<br>
	<br>	
    <section class="about flex-box" style="background-color:#8c9090;text-align:center;color:wheat">
		<div class="container" style="">
			<div style="margin-top:15px">
				<span>FOLLOW US</span>
			</div>
			<div style="font-size:xx-large">
				<a href="https://www.linkedin.com/company/reandabernardi/" style="color:wheat"><span class="fa fa-linkedin"></span></a>			
			</div>
		</div>
	</section>
@endsection
